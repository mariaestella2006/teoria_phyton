#05/06: operadores matemáticos

# print("*****OPERAÇÕES*****")
n1 = 10
n2 = 5

#soma
soma = n1+n2
print("Soma =", soma)
print("Soma=", str(n1+n2)) #jeito de simplificar e não criar tanta variável
print(f"soma")

#subtração
subtracao = n1-n2
print("Subtracao =", subtracao)
print("Subtracao=", str(n1-n2))

#multiplicacao
multiplicacao = n1 * n2
print("Multiplicacao=", multiplicacao)
print("Multiplicacao=", str(n1*n2))


#divisao
divisao = n1 / n2
print("Divisao=",divisao)
print("Divisao=", str(n1/n2))

# #OPERADOR DE DIVISÃO INTEIRA:
divisaoInteira= n1//n2
print("Divisao Inteira=", divisaoInteira)

potencia = n1 ** n2
print("Potencia=", potencia)

restoDivisao= n1%n2
print("Resto da divisao=", restoDivisao)

divInteira=5//2
print(f"Divisao 5/2={5/2}")
