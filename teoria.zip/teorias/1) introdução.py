#04/06: introdução

# print("senai nami jafet")  #palavrinhas amarelas= comandos do próprio python
# #palavrinhas vermelhas= nomes 

nome = "maria estella" #palavrinhas azuis= variáveis que eu criei

salario = 1200.50
salarioBruto = 2050.33 #camecase
salario_bruto = 3300.25 #snakecase

print("Salario =" , salario)
salario = salario+ 150.00 #salario=1200.5+150=1350.50

print(salarioBruto)
print(salario_bruto)

# print("Salario Atualizado="+salario) CTRL+; (faz o comentário de tudo)
