#05/06: variáveis, print, input

print("******LEITURA*******")

numeroInteiro= int(input("Digite um numero inteiro:"))
print(f"Numero digitado = {numeroInteiro}")

numeroReal= float(input("Digite um numero real:"))
print(f"Numero digitado = {numeroReal}")

booleano= bool(input("Digite um valor booleano:"))
print(f"Valor boleano digitado = {booleano}")

# #IDENTIFICAR O TIPO PRIMITIVO
variavel1= 345
print(type(variavel1))

variavel2= 1.89
print(type(variavel2))

variavel3= "djgifn"
print(type(variavel3))

variavel4= "false"
print(type(variavel4))

#ANÁLISE DE VARIÁVEL
texto= "12345"
print(texto.isnumeric())
print(texto.isalpha())

texto2= "anthony"
print(texto2.islower())
print(texto2.isupper())