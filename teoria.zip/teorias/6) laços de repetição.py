#12/06: loop e for

# #ESTRUTURA DE REPETIÇÃO:
# É um recurso responsável por executar um bloco de código repetidas vezes enquanto uma ação é verdadeira.
# No python, temos o FOR e WHILE. Esse loop continua sendo executado até que determinada ação seja executada.

# #COMANDO FOR:
# Usado quando eu quero repetir um determinado número fixas vezes.
# Ex: montar uma taboada
#NOMENCLATURA: for elemento in range (inicio, fim, salto):

for contador in range (0,6,2):#(0-número inicial, 6-número final, 2-pulando de dois em dois)
    print(contador)
print("Fim!") #essa linha está fora do if para não entrar no loop
#
#contador= contador +1
#contador++

#exemplo1
nome="Jundiapeba"
for caracter in nome:
    print(caracter)

#exemplo2
zoozoo=["Zebra",15, "Canguru",9, "Gorila",27, "Javali",8, "Hiena",4]
for animal in zoozoo:
    print(animal)

#exemplo3
numeros = [1, 2, 3, 10, 12]
for numero in numeros:
    if numero == 10:
        break
    print(f'numero= {numero}')
else: 
    print("Acabou")
print("Até mais!!")

#exemplo4
for x in [1, 10, 20, 30, 40, 50]: #x= variável
    if x ==30:
        continue
    print(x)